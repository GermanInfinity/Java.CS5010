Description: 
This assignment implements a Bird super class, Conservatory class, 
and Aviary class. These classes have functionalities as specified in the 
homework. 
Hours spent: 
50 hours
Changes made: 
Very minimal changes made in comparison to stated design doc.
Challenges faced: 
Implementing a grandchild of the bird class, I ran into issues with 
the constructor of the Shorebird class being declared in the waterfowl class. 
I had to call a dummy constructor to solve this issue. 
Creaing JAR file was an issue for me as my version of eclipse did things 
differently to what was specified. 
This homework was interesting but I took too long to complete it, perhaps
this was due to my first time usinig Java.
